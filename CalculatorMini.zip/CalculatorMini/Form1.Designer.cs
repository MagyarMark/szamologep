﻿namespace CalculatorMini
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnequal = new System.Windows.Forms.Button();
            this.btnplusminus = new System.Windows.Forms.Button();
            this.btnvesszo = new System.Windows.Forms.Button();
            this.btnplus = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btnminus = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btntimes = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btnsquare = new System.Windows.Forms.Button();
            this.btndivide = new System.Windows.Forms.Button();
            this.btnCA = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.labelDisplay = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn0.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn0, "btn0");
            this.btn0.ForeColor = System.Drawing.Color.White;
            this.btn0.Name = "btn0";
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btnequal
            // 
            this.btnequal.BackColor = System.Drawing.Color.Gold;
            this.btnequal.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnequal, "btnequal");
            this.btnequal.ForeColor = System.Drawing.Color.White;
            this.btnequal.Name = "btnequal";
            this.btnequal.UseVisualStyleBackColor = false;
            // 
            // btnplusminus
            // 
            this.btnplusminus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnplusminus.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnplusminus, "btnplusminus");
            this.btnplusminus.ForeColor = System.Drawing.Color.White;
            this.btnplusminus.Name = "btnplusminus";
            this.btnplusminus.UseVisualStyleBackColor = false;
            this.btnplusminus.Click += new System.EventHandler(this.btnplusminus_Click);
            // 
            // btnvesszo
            // 
            this.btnvesszo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnvesszo.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnvesszo, "btnvesszo");
            this.btnvesszo.ForeColor = System.Drawing.Color.White;
            this.btnvesszo.Name = "btnvesszo";
            this.btnvesszo.UseVisualStyleBackColor = false;
            this.btnvesszo.Click += new System.EventHandler(this.btnvesszo_Click);
            // 
            // btnplus
            // 
            this.btnplus.BackColor = System.Drawing.Color.Gold;
            this.btnplus.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnplus, "btnplus");
            this.btnplus.ForeColor = System.Drawing.Color.White;
            this.btnplus.Name = "btnplus";
            this.btnplus.UseVisualStyleBackColor = false;
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn3.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn3, "btn3");
            this.btn3.ForeColor = System.Drawing.Color.White;
            this.btn3.Name = "btn3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn2.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn2, "btn2");
            this.btn2.ForeColor = System.Drawing.Color.White;
            this.btn2.Name = "btn2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn1.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn1, "btn1");
            this.btn1.ForeColor = System.Drawing.Color.White;
            this.btn1.Name = "btn1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn5.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn5, "btn5");
            this.btn5.ForeColor = System.Drawing.Color.White;
            this.btn5.Name = "btn5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn4.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn4, "btn4");
            this.btn4.ForeColor = System.Drawing.Color.White;
            this.btn4.Name = "btn4";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btnminus
            // 
            this.btnminus.BackColor = System.Drawing.Color.Gold;
            this.btnminus.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnminus, "btnminus");
            this.btnminus.ForeColor = System.Drawing.Color.White;
            this.btnminus.Name = "btnminus";
            this.btnminus.UseVisualStyleBackColor = false;
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn6.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn6, "btn6");
            this.btn6.ForeColor = System.Drawing.Color.White;
            this.btn6.Name = "btn6";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn9.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn9, "btn9");
            this.btn9.ForeColor = System.Drawing.Color.White;
            this.btn9.Name = "btn9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btntimes
            // 
            this.btntimes.BackColor = System.Drawing.Color.Gold;
            this.btntimes.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btntimes, "btntimes");
            this.btntimes.ForeColor = System.Drawing.Color.White;
            this.btntimes.Name = "btntimes";
            this.btntimes.UseVisualStyleBackColor = false;
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn7.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn7, "btn7");
            this.btn7.ForeColor = System.Drawing.SystemColors.Window;
            this.btn7.Name = "btn7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btn8.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn8, "btn8");
            this.btn8.ForeColor = System.Drawing.Color.White;
            this.btn8.Name = "btn8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btnsquare
            // 
            this.btnsquare.BackColor = System.Drawing.Color.Gray;
            this.btnsquare.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnsquare, "btnsquare");
            this.btnsquare.ForeColor = System.Drawing.Color.White;
            this.btnsquare.Name = "btnsquare";
            this.btnsquare.UseVisualStyleBackColor = false;
            // 
            // btndivide
            // 
            this.btndivide.BackColor = System.Drawing.Color.Gold;
            this.btndivide.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btndivide, "btndivide");
            this.btndivide.ForeColor = System.Drawing.Color.White;
            this.btndivide.Name = "btndivide";
            this.btndivide.UseVisualStyleBackColor = false;
            // 
            // btnCA
            // 
            this.btnCA.BackColor = System.Drawing.Color.Gray;
            this.btnCA.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnCA, "btnCA");
            this.btnCA.ForeColor = System.Drawing.Color.White;
            this.btnCA.Name = "btnCA";
            this.btnCA.UseVisualStyleBackColor = false;
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.Gray;
            this.btnC.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnC, "btnC");
            this.btnC.ForeColor = System.Drawing.Color.White;
            this.btnC.Name = "btnC";
            this.btnC.UseVisualStyleBackColor = false;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // labelDisplay
            // 
            this.labelDisplay.BackColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.labelDisplay, "labelDisplay");
            this.labelDisplay.ForeColor = System.Drawing.Color.White;
            this.labelDisplay.Name = "labelDisplay";
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.Controls.Add(this.labelDisplay);
            this.Controls.Add(this.btnsquare);
            this.Controls.Add(this.btndivide);
            this.Controls.Add(this.btnCA);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btntimes);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btnminus);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btnplus);
            this.Controls.Add(this.btnvesszo);
            this.Controls.Add(this.btnplusminus);
            this.Controls.Add(this.btnequal);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.button1);
            this.ForeColor = System.Drawing.Color.Transparent;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnequal;
        private System.Windows.Forms.Button btnplusminus;
        private System.Windows.Forms.Button btnvesszo;
        private System.Windows.Forms.Button btnplus;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btnminus;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btntimes;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btnsquare;
        private System.Windows.Forms.Button btnCA;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Label labelDisplay;
        private System.Windows.Forms.Button btndivide;
    }
}

